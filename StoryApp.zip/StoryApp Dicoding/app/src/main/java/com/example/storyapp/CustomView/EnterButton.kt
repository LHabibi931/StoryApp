package com.example.storyapp.CustomView

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import com.example.storyapp.R

class EnterButton: AppCompatButton {

    private lateinit var enabledButton: Drawable
    private lateinit var disabledButton: Drawable

    constructor(context: Context): super(context){
        init()

    }

    constructor(context: Context, attrs: AttributeSet): super(context, attrs){
        init()

    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int): super(context, attrs,defStyleAttr){
        init()
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        background = if (isEnabled){ enabledButton }
                     else{disabledButton}
        gravity = Gravity.CENTER
    }

    private fun init(){
        enabledButton = ContextCompat.getDrawable(context, R.drawable.button_enable) as Drawable
        disabledButton = ContextCompat.getDrawable(context, R.drawable.button_dissable) as Drawable
    }
}