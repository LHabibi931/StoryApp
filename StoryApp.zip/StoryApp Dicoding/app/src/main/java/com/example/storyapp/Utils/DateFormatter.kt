package com.example.storyapp.Utils


import android.os.Build
import androidx.annotation.RequiresApi
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object DateFormatter {

    @RequiresApi(Build.VERSION_CODES.O)
    fun formatDate(currentDateString: String, targetZone: String): String{
        val instant = Instant.parse(currentDateString)
        val converter = DateTimeFormatter.ofPattern("dd MMM yyyy | HH:mm")
            .withZone(ZoneId.of(targetZone))
        return converter.format(instant)
    }
}