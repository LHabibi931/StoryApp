package com.example.storyapp.CustomView

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Patterns
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.example.storyapp.R

class EmailEditText: AppCompatEditText, View.OnTouchListener {

    private lateinit var emailImage: Drawable


    constructor(context: Context): super(context){
        init()

    }

    constructor(context: Context, attrs: AttributeSet): super(context, attrs){
        init()

    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int): super(context, attrs,defStyleAttr){
        init()
    }

    override fun onTouch(view: View, mev: MotionEvent): Boolean {
        TODO("Not yet implemented")
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)


    }

    private fun init(){
        emailImage = ContextCompat.getDrawable(context, R.drawable.baseline_email_24) as Drawable
        setCompoundDrawablesWithIntrinsicBounds(emailImage,null, null,null)

        addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                //nothing
            }

            override fun onTextChanged(cs: CharSequence?, p1: Int, p2: Int, p3: Int) {
               //nothing

            }

            override fun afterTextChanged(editable: Editable?) {
                val email = editable.toString()
                val validEmail = Patterns.EMAIL_ADDRESS.matcher(email).matches()
                if(validEmail){
                    error = null
                }
                else{
                    error = context.getString(R.string.email_hint)
                }
            }

        })

    }


}