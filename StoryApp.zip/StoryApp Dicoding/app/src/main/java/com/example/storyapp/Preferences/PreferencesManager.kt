package com.example.storyapp.Preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.storyapp.PagingSource.StoryPagingSource

class PreferencesManager(context: Context) {

    private var prefManager: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE)
    private val editPref = prefManager.edit()

    fun stringPreference(key: String, value: String){
        editPref.putString(key, value)
        editPref.apply()
    }

    fun booleanPreference(key: String, value: Boolean){
        editPref.putBoolean(key, value)
        editPref.apply()
    }

    fun clearPreference(){
        editPref.clear().apply()
    }

    val token = prefManager.getString(KEY_AUTH, "")
    val id = prefManager.getString(USER_ID, "")
    val username = prefManager.getString(USERNAME, "")
    val email = prefManager.getString(USER_EMAIL, "")




    companion object{
        const val PREFERENCE_NAME = "my_pref"
        const val KEY_AUTH = "auth_token"
        const val LOGIN_STAT = "Login_stat"
        const val USER_ID = "user_id"
        const val USERNAME = "username"
        const val USER_EMAIL = "user_email"
        const val GET_STORY_ID = "story_id"
    }
}