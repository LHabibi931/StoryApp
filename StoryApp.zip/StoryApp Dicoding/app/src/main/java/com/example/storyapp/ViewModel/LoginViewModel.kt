package com.example.storyapp.ViewModel


import android.content.ContentValues.TAG
import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp.ApiConfig.ApiService
import com.example.storyapp.ApiConfig.RetrofitBuild
import com.example.storyapp.ApiResponse.LoginResponse
import com.example.storyapp.ApiResponse.LoginResult
import retrofit2.Call
import retrofit2.Response

class LoginViewModel: ViewModel() {
    private val loginRespon = MutableLiveData<LoginResponse>()
    private val loading = MutableLiveData<Boolean>()


    val _email = MutableLiveData("")

    fun loginToApp(email: String, password: String){
        loading.value = true
        _email.postValue(email)
        val client = RetrofitBuild.getApiService().login(email, password)
        client.enqueue(object :retrofit2.Callback<LoginResponse>{
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful){
                    loading.value = false
                   loginRespon.value = response.body()
                }

                else{
                    Log.e(TAG, "fail:${response.message()}")
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                loading.value = false
                Log.e(TAG, "fail:${t.message}")
            }

        })
    }
    fun getLogin(): LiveData<LoginResponse>{
        return loginRespon
    }

}