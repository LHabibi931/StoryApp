package com.example.storyapp.Ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.Preferences.PreferencesManager
import com.example.storyapp.ViewModel.LoginViewModel
import com.example.storyapp.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var sharedPreferences: PreferencesManager
    private lateinit var viewModel: LoginViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)


        viewModel = ViewModelProvider(this).get(LoginViewModel::class.java)
        sharedPreferences = PreferencesManager(this)


        binding.etEmail.addTextChangedListener(object :TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                setButtonEnable()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })
        binding.etPassword.addTextChangedListener(object :TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                setButtonEnable()
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })


        binding.loginButton.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()

            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches() && password.length < 8){
                Toast.makeText(this, "Please input proper email & password", Toast.LENGTH_SHORT).show()
            }

                val tokenPref = PreferencesManager.KEY_AUTH
                val idPref = PreferencesManager.USER_ID
                val emailPref = PreferencesManager.USER_EMAIL
                val namePref = PreferencesManager.USERNAME
                val loginStat = PreferencesManager.LOGIN_STAT
                viewModel.loginToApp(email, password)

                showLoading(true)
                viewModel.getLogin().observe(this, {
                    sharedPreferences.apply {
                        stringPreference(idPref, it.loginResult.userId)
                        stringPreference(tokenPref, it.loginResult.token)
                        stringPreference(namePref, it.loginResult.name)
                        stringPreference(emailPref, viewModel._email.value.toString())
                        booleanPreference(loginStat, true)
                    }
                    if(it.loginResult.token != null){
                        startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                        finish()
                        Toast.makeText(this, "Wellcome "+ it.loginResult.name, Toast.LENGTH_SHORT).show()
                    }

                })

        }

        binding.registerText.setOnClickListener {
            Intent(this@LoginActivity, RegisterActivity::class.java).also{
                startActivity(it)
            }
        }
        playAnimation()

    }

    private fun setButtonEnable(){
        val email = binding.etEmail.text
        val password = binding.etPassword.text
        binding.loginButton.isEnabled = password != null &&
                                        email != null &&
                                        email.toString().isNotEmpty() &&
                                        password.toString().isNotEmpty()


    }

    private fun playAnimation(){
        ObjectAnimator.ofFloat(binding.imageView, View.TRANSLATION_X, -20f,20f).apply {
            duration = 5000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val login = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(500)
        val etEmail = ObjectAnimator.ofFloat(binding.etEmail, View.ALPHA, 1f).setDuration(500)
        val etPassword = ObjectAnimator.ofFloat(binding.etPassword, View.ALPHA, 1f).setDuration(500)
        val title = ObjectAnimator.ofFloat(binding.title, View.ALPHA, 1f).setDuration(500)
        val textBox = ObjectAnimator.ofFloat(binding.linearLayout, View.ALPHA, 1f).setDuration(500)

        val appearTogether = AnimatorSet().apply {
            playTogether(etEmail, etPassword)
        }

        AnimatorSet().apply {
            playSequentially(title, appearTogether, login,textBox,)
            start()
        }


    }

    private fun showLoading(isLoading: Boolean){
        binding.progressBar.visibility = if (isLoading) View.VISIBLE
                                         else View.GONE
    }
}