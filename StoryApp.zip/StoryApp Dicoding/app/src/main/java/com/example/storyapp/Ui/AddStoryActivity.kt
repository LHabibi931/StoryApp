package com.example.storyapp.Ui

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.content.Intent.ACTION_GET_CONTENT
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.Preferences.PreferencesManager
import com.example.storyapp.Utils.createCustomTempFile
import com.example.storyapp.Utils.reduceFileImage
import com.example.storyapp.Utils.uriToFile
import com.example.storyapp.ViewModel.AddStoryViewModel
import com.example.storyapp.databinding.ActivityAddStoryBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.snackbar.Snackbar
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File

class AddStoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddStoryBinding
    private var fileImage: File? = null
    private lateinit var sharedPreferences: PreferencesManager
    private lateinit var viewModel: AddStoryViewModel
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private  var userLocation: Location? = null


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_PERMISSIONS_CODE){
            if(!permissionsGranted()){
                Toast.makeText(this, "Permissions not allowed", Toast.LENGTH_SHORT).show()
                finish()

            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)


        sharedPreferences = PreferencesManager(this)
        viewModel = ViewModelProvider(this).get(AddStoryViewModel::class.java)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (!permissionsGranted()){
            ActivityCompat.requestPermissions(this, PERISSIONS, REQUEST_PERMISSIONS_CODE)
        }

        binding.backButton.setOnClickListener {
            val intent = Intent(this@AddStoryActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.imagePreview.addOnLayoutChangeListener{_, _, _, _, _, _, _, _, _ ->
            setButtonEnable()
        }

        binding.etDescription.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) { setButtonEnable() }
            override fun afterTextChanged(p0: Editable?) {}

        })


        binding.takePhoto.setOnClickListener { takePhoto() }
        binding.imagePreview.setOnClickListener { takePhoto() }
        binding.fromGalery.setOnClickListener { takeGallery() }
        binding.uploadStory.setOnClickListener {
            val file = reduceFileImage(fileImage as File)
            val token = sharedPreferences.token
            val description = binding.etDescription.text.toString().toRequestBody("text/plain".toMediaType())
            val requestImageFile = file.asRequestBody("image/jpeg".toMediaType())
            val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
                "photo",
                file.name,
                requestImageFile
            )

            var lat: RequestBody? = null
            var lon: RequestBody? = null

            if (userLocation != null){
                lat = userLocation?.latitude.toString().toRequestBody("text/plain".toMediaType())
                lon = userLocation?.longitude.toString().toRequestBody("text/plain".toMediaType())

            }


            viewModel.uploadToServer("Bearer $token", imageMultipart, description, lat, lon)
            viewModel.uploadStory().observe(this,{
                if (!it.error!!) {
                    Toast.makeText(this, "Story Uploaded Successful", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()

                }
            })

        }
        binding.sharelocCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if(isChecked){
                getLocation()
            }
        }

        playAnimation()
    }

    private fun permissionsGranted() = PERISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext,it) == PackageManager.PERMISSION_GRANTED
    }

    private lateinit var currentPhoto: String
    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){
        if (it.resultCode == RESULT_OK){
            val myFile = File(currentPhoto)

            myFile.let {file ->
                fileImage = file
                binding.imagePreview.setImageBitmap(BitmapFactory.decodeFile(file.path))
            }

        }

    }

    private val takeFromGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ){ result ->
        if (result.resultCode == RESULT_OK){
            val selectedImage = result.data?.data as Uri
            selectedImage.let {uri ->
            val myfile = uriToFile(uri, this@AddStoryActivity)
            fileImage = myfile
            binding.imagePreview.setImageURI(uri)

            }
        }

    }

    private val requestPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted: Boolean ->
            if (isGranted) {
                getLocation()

            }
            else{
                binding.sharelocCheckBox.isChecked = false
                Toast.makeText(this,"\tplease enable services location through settings\t",Toast.LENGTH_SHORT).show()


            }
        }

    private fun getLocation() {
        if (ContextCompat.checkSelfPermission(
                this.applicationContext,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location != null) {
                        userLocation = location
                        location.latitude
                        location.longitude
                    }
                    else {
                        Toast.makeText(this, "Location Not Found", Toast.LENGTH_SHORT).show()
                    }
                }
        }
        else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    }


    private fun takePhoto(){
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)

        createCustomTempFile(application).also {
            val photoURI: Uri = FileProvider.getUriForFile(
                this@AddStoryActivity,
                "com.example.storyapp", it
            )

            currentPhoto = it.absolutePath
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            launcherIntentCamera.launch(intent)
        }
    }



    private fun takeGallery(){
        val intent = Intent()
        intent.action = ACTION_GET_CONTENT
        intent.type = "image/*"
        val pick = Intent.createChooser(intent, "Select Picture")
        takeFromGallery.launch(pick)
    }



    private fun setButtonEnable(){
        val image = binding.imagePreview.drawable
        val text = binding.etDescription.text
        binding.uploadStory.isEnabled =  image != null &&
                                         text != null &&
                                         text.toString().isNotEmpty()

    }


    private fun playAnimation(){
        ObjectAnimator.ofFloat(binding.imageContainer, View.TRANSLATION_X, -20f,20f).apply {
            duration = 5000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val photoButton = ObjectAnimator.ofFloat(binding.takePhoto, View.ALPHA, 1f).setDuration(500)
        val galleryButton = ObjectAnimator.ofFloat(binding.fromGalery, View.ALPHA, 1f).setDuration(500)
        val descText = ObjectAnimator.ofFloat(binding.etDescription, View.ALPHA, 1f).setDuration(500)
        val title = ObjectAnimator.ofFloat(binding.title, View.ALPHA, 1f).setDuration(500)
        val descDescription = ObjectAnimator.ofFloat(binding.descDescription, View.ALPHA, 1f).setDuration(500)
        val uploadButton = ObjectAnimator.ofFloat(binding.uploadStory, View.ALPHA, 1f).setDuration(500)



        val appearTogether = AnimatorSet().apply {
            playTogether(photoButton, galleryButton, descText, descDescription)
        }

        AnimatorSet().apply {
            playSequentially(title, appearTogether , uploadButton)
            start()
        }


    }


    companion object{
        private val PERISSIONS = arrayOf(Manifest.permission.CAMERA)
        private const val REQUEST_PERMISSIONS_CODE = 10
    }

}



