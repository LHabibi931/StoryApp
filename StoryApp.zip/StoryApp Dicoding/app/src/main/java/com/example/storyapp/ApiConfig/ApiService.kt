package com.example.storyapp.ApiConfig

import com.example.storyapp.ApiResponse.AddStoriesResponse
import com.example.storyapp.ApiResponse.DetailStoriesResponse
import com.example.storyapp.ApiResponse.GetAllStoriesResponse
import com.example.storyapp.ApiResponse.ListStoryItem
import com.example.storyapp.ApiResponse.LoginResponse
import com.example.storyapp.ApiResponse.RegisterResponse
import com.example.storyapp.ApiResponse.Story
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @FormUrlEncoded
    @POST("login")
    fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<LoginResponse>

    @FormUrlEncoded
    @POST("register")
    fun register(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<RegisterResponse>

    @GET("stories")
     suspend fun getAllStories(
        @Header("Authorization") token: String,
        @Query("page") page: Int,
        @Query("size") size: Int,
    ): GetAllStoriesResponse

    @Multipart
    @POST("stories")
    fun addNewStory(
        @Header("Authorization") token: String,
        @Part file: MultipartBody.Part,
        @Part("description") description: RequestBody?,
        @Part("lat") lat: RequestBody? = null,
        @Part("lon") lon: RequestBody? = null
    ): Call<AddStoriesResponse>

    @GET("stories/{id}")
    fun getDetailStory(
        @Header("Authorization") token: String,
        @Path("id") id: String
    ):Call<DetailStoriesResponse>

    @GET("stories")
    fun getLocation(
        @Header("Authorization") token: String,
        @Query("size") size: Int?,
        @Query("location") location: Int? = null,
    ): Call<GetAllStoriesResponse>

}
