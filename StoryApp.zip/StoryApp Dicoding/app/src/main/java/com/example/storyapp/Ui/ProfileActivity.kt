package com.example.storyapp.Ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.storyapp.Preferences.PreferencesManager
import com.example.storyapp.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var sharedPreferences: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = PreferencesManager(this)
        val username = sharedPreferences.username
        val email = sharedPreferences.email

        binding.backButton.setOnClickListener {
            val intent = Intent(this@ProfileActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.tvUsername.text = "$username"
        binding.tvEmail.text = "$email"

        binding.logoutButton.setOnClickListener {
            sharedPreferences.clearPreference()
            val intent = Intent(this@ProfileActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()

        }
    }






}

