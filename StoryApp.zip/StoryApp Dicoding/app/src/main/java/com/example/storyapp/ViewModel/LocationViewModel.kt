package com.example.storyapp.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp.ApiConfig.RetrofitBuild
import com.example.storyapp.ApiResponse.GetAllStoriesResponse
import com.example.storyapp.ApiResponse.ListStoryItem
import retrofit2.Call
import retrofit2.Response

class LocationViewModel: ViewModel() {


    private val storiesLocation = MutableLiveData<List<ListStoryItem>>()

    fun loadStoriesLocation(token: String,  size: Int, location: Int?) {
        val client = RetrofitBuild.getApiService().getLocation("$token", size, location)
        client.enqueue(object : retrofit2.Callback<GetAllStoriesResponse>{
            override fun onResponse(call: Call<GetAllStoriesResponse>, response: Response<GetAllStoriesResponse>) {
                if (response.isSuccessful){
                    val allStoriesResponse = response.body()
                    if (allStoriesResponse != null && !allStoriesResponse.error){
                        storiesLocation.postValue(allStoriesResponse.listStory)

                    }
                }

                else{
                    Log.e(TAG,"failure:${response.message()}")
                }
            }

            override fun onFailure(call: Call<GetAllStoriesResponse>, t: Throwable) {
                Log.e(TAG,"failure:${t.message}")
            }

        })

    }
    fun getStories(): LiveData<List<ListStoryItem>> {
        return  storiesLocation
    }


    companion object {
        const val TAG = "Location View Model"
    }
}