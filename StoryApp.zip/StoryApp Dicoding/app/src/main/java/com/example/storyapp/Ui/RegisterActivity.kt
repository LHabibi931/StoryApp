package com.example.storyapp.Ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.ViewModel.RegisterViewModel
import com.example.storyapp.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterBinding
    private lateinit var viewModel: RegisterViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)


        viewModel = ViewModelProvider(this).get(RegisterViewModel::class.java)


        binding.regisButton.setOnClickListener{

            val name = binding.userName.text.toString()
            val email = binding.etEmail.text.toString()
            val password = binding.etPassword.text.toString()
            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                Toast.makeText(this, "Please input proper email & password", Toast.LENGTH_SHORT).show()
            }

            else if (password.length < 8){
                Toast.makeText(this, "Please input proper email & password", Toast.LENGTH_SHORT).show()
            }

            else if(name.isEmpty()){
                Toast.makeText(this, "Please input username", Toast.LENGTH_SHORT).show()
            }


            else{
                viewModel.registerToApp(name, email, password)
                showLoading(true)

                viewModel.getRegis().observe(this, {
                    if (!it.error) {
                        Toast.makeText(this, "Register is Successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, LoginActivity::class.java)
                        startActivity(intent)
                        finish()

                    }
                })

            }
        }

        binding.loginText.setOnClickListener {
            Intent(this, LoginActivity::class.java).also{
                startActivity(it)
            }
        }
        playAnimation()

    }

    private fun playAnimation(){

        val etEmail = ObjectAnimator.ofFloat(binding.etEmail, View.ALPHA, 1f).setDuration(500)
        val etPassword = ObjectAnimator.ofFloat(binding.etPassword, View.ALPHA, 1f).setDuration(500)
        val etUsername = ObjectAnimator.ofFloat(binding.userName, View.ALPHA, 1f).setDuration(500)
        val title = ObjectAnimator.ofFloat(binding.title, View.ALPHA, 1f).setDuration(500)
        val regisButton = ObjectAnimator.ofFloat(binding.regisButton, View.ALPHA, 1f).setDuration(500)
        val textBox = ObjectAnimator.ofFloat(binding.textBox, View.ALPHA, 1f).setDuration(500)


        val appearTogether = AnimatorSet().apply {
            playTogether(etEmail, etUsername, etPassword)
        }

        AnimatorSet().apply {
            playSequentially(title, appearTogether ,regisButton, textBox)
            start()
        }


    }


    private fun showLoading(isLoading: Boolean){
        binding.progressBar.visibility = if (isLoading) View.VISIBLE
        else View.GONE
    }

}