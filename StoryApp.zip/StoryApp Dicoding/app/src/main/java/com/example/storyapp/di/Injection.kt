package com.example.storyapp.di

import android.content.Context
import com.example.storyapp.ApiConfig.RetrofitBuild
import com.example.storyapp.Preferences.PreferencesManager
import com.example.storyapp.Repository.StoryRepository

object Injection {
    fun injectRepository(context: Context): StoryRepository {
        val apiService = RetrofitBuild.getApiService()
        return StoryRepository(apiService, context)
    }
}