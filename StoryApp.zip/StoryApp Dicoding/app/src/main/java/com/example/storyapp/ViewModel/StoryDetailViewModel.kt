package com.example.storyapp.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp.ApiConfig.RetrofitBuild
import com.example.storyapp.ApiResponse.DetailStoriesResponse
import retrofit2.Call
import retrofit2.Response

class StoryDetailViewModel: ViewModel() {

    val storyDetail = MutableLiveData<DetailStoriesResponse>()


    fun getStoryDetail(token: String, id:String){
        val client = RetrofitBuild.getApiService().getDetailStory("$token", id)
        client.enqueue(object : retrofit2.Callback<DetailStoriesResponse>{
            override fun onResponse(call: Call<DetailStoriesResponse>, response: Response<DetailStoriesResponse> ) {
                if (response.isSuccessful){
                    storyDetail.value = response.body()
                }

                else{
                    Log.e(TAG, "fail:${response.message()}")
                }

            }

            override fun onFailure(call: Call<DetailStoriesResponse>, t: Throwable) {
                Log.e(TAG, "fail:${t.message}")
            }

        })
    }

    fun getDetail(): LiveData<DetailStoriesResponse>{
        return  storyDetail
    }

    companion object{
        private const val TAG = "StoryDetailViewModel"
    }
}