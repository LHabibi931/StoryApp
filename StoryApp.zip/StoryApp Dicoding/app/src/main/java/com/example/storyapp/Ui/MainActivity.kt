package com.example.storyapp.Ui

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.storyapp.Adapter.ListStoryAdapter
import com.example.storyapp.ApiResponse.ListStoryItem
import com.example.storyapp.Map.MapsActivity
import com.example.storyapp.Preferences.PreferencesManager
import com.example.storyapp.R
import com.example.storyapp.ViewModel.NewMainViewModel
import com.example.storyapp.databinding.ActivityMainBinding
import androidx.activity.viewModels
import com.example.storyapp.ViewModel.ViewModelFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var sharedPreferences: PreferencesManager
    private lateinit var adapter: ListStoryAdapter
    private val viewModel : NewMainViewModel by viewModels{
        ViewModelFactory(this)
}



    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPreferences = PreferencesManager(this)
        val token = sharedPreferences.token


        if (token!!.isEmpty()){
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.rvStory.layoutManager = LinearLayoutManager(this)
        adapter = ListStoryAdapter()
        binding.rvStory.adapter = adapter
        viewModel.getStoryResult().observe(this,{
            adapter.submitData(lifecycle,it)
        })

        val storyClickListener = object :ListStoryAdapter.OnItemClickListener{
            override fun onItemClick(listStoryItem: ListStoryItem) {
                Intent(this@MainActivity, StoryDetail::class.java).also {
                    it.putExtra("name",listStoryItem.name)
                    it.putExtra("photoUrl", listStoryItem.photoUrl)
                    it.putExtra("description", listStoryItem.description)
                    it.putExtra("id", listStoryItem.id)

                    startActivity(it)
                }
            }

        }
        adapter.onItemClick = storyClickListener



        binding.addStory.setOnClickListener {
            val intent = Intent(this@MainActivity, AddStoryActivity::class.java)
            startActivity(intent)
            finish()
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.to_profile ->{
                Intent(this@MainActivity, ProfileActivity::class.java).also {
                    startActivity(it)
                }
                return true
            }

            R.id.to_map ->{
                Intent(this@MainActivity, MapsActivity::class.java).also {
                    startActivity(it)
                }
                return true
            }

        }
        return onOptionsItemSelected(item)
    }


}

