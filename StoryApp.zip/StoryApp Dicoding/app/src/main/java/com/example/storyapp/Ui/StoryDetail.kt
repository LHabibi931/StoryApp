package com.example.storyapp.Ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.storyapp.ApiResponse.ListStoryItem
import com.example.storyapp.ApiResponse.Story
import com.example.storyapp.Preferences.PreferencesManager
import com.example.storyapp.ViewModel.StoryDetailViewModel
import com.example.storyapp.Preferences.PreferencesManager.Companion.GET_STORY_ID
import com.example.storyapp.databinding.ActivityStoryDetailBinding

class StoryDetail : AppCompatActivity() {

    private lateinit var binding: ActivityStoryDetailBinding
    private lateinit var viewModel: StoryDetailViewModel
    private lateinit var sharedPreferences: PreferencesManager


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)


        val story = intent.getParcelableExtra<ListStoryItem>(GET_STORY_ID) as ListStoryItem

        viewModel = ViewModelProvider(this).get(StoryDetailViewModel::class.java)
        sharedPreferences = PreferencesManager(this)
        val token = sharedPreferences.token

        viewModel.getStoryDetail("Bearer $token", story.id)
        viewModel.getDetail().observe(this){
            setAllStoryDetail(it.story)
        }


    }


    private fun setAllStoryDetail(detail: Story){

            binding.apply {
            tvUsername.text = detail.name
                tvDescription.text = detail.description
                Glide.with(this@StoryDetail)
                    .load(detail.photoUrl)
                    .into(storyImage)

            }
    }

    companion object{
        const val USERNAME = "username"
    }
}