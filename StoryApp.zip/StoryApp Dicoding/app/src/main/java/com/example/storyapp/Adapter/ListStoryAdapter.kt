package com.example.storyapp.Adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.storyapp.ApiResponse.ListStoryItem
import com.example.storyapp.Preferences.PreferencesManager.Companion.GET_STORY_ID
import com.example.storyapp.Ui.StoryDetail
import com.example.storyapp.Utils.DateFormatter
import com.example.storyapp.databinding.StoryItemBinding
import java.util.TimeZone


class ListStoryAdapter: PagingDataAdapter<ListStoryItem, ListStoryAdapter.ViewHolder>(CALLBACK) {

    var onItemClick: OnItemClickListener? = null

    interface OnItemClickListener{
        fun onItemClick(listStoryItem: ListStoryItem)
    }

    inner class ViewHolder(private val binding: StoryItemBinding, onItemClick: OnItemClickListener?): RecyclerView.ViewHolder(binding.root)
    {
        init {
            binding.root.setOnClickListener{
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION){
                    val story = getItem(position)
                    story?.let { onItemClick?.onItemClick(it) }

                }
            }
        }


        fun bind(story: ListStoryItem?){
            Glide.with(itemView.context)
                .load(story?.photoUrl)
                .into(binding.storyImage)
            binding.userName.text = story?.name
            binding.createDate.text =
                DateFormatter.formatDate(story?.createdAt.toString(), TimeZone.getDefault().id)

        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListStoryAdapter.ViewHolder {
        val view = StoryItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(view, onItemClick)
    }

    override fun onBindViewHolder(holder: ListStoryAdapter.ViewHolder, position: Int) {
        val story = getItem(position)
        holder.bind(story)
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, StoryDetail::class.java).apply {
                putExtra(GET_STORY_ID, story)
            }

            holder.itemView.context.
            startActivity(intent, ActivityOptionsCompat.makeSceneTransitionAnimation
                (holder.itemView.context as Activity).toBundle())
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

    }

    companion object{
        val CALLBACK = object : DiffUtil.ItemCallback<ListStoryItem>(){
            override fun areItemsTheSame(oldItem: ListStoryItem, newItem: ListStoryItem): Boolean {
                return oldItem == newItem
            }

            override fun areContentsTheSame(
                oldItem: ListStoryItem,
                newItem: ListStoryItem
            ): Boolean {
                return  oldItem.id == newItem.id
            }

        }
    }

}

