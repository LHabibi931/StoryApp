package com.example.storyapp.ViewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp.ApiConfig.RetrofitBuild
import com.example.storyapp.ApiResponse.RegisterResponse
import okhttp3.Callback
import retrofit2.Call
import retrofit2.Response

class RegisterViewModel: ViewModel() {
    private val registerResult = MutableLiveData<RegisterResponse>()
    private val loading = MutableLiveData<Boolean>()

    fun registerToApp(name: String, email: String, password: String){
        loading.value = true
        val client = RetrofitBuild.getApiService().register(name, email, password)
        client.enqueue(object : retrofit2.Callback<RegisterResponse>{
            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse> ) {
                if(response.isSuccessful){
                    loading.value = false
                    registerResult.value = response.body()
                }

                else{
//                    Log.e(TAG, "fail: ${response.message()}")
                }
              }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                loading.value = false
//                Log.e(TAG, "fail:${t.message}")
            }

        })
    }

    fun getRegis(): LiveData<RegisterResponse>{
        return registerResult
    }


}