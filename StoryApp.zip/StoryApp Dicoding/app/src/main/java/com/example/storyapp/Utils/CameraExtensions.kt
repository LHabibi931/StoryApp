package com.example.storyapp.Utils

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale

private const val FILE_FORMAT = "dd-MMM-yyyy"
private const val MAX_SIZE = 1000000

val timestamp: String = SimpleDateFormat(
    FILE_FORMAT,
    Locale.US
).format(System.currentTimeMillis())


fun createCustomTempFile(context: Context): File{
    val storageDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
    return  File.createTempFile(timestamp, ".jpg", storageDir)
}

fun uriToFile(selectedImage: Uri, context: Context): File{
    val contentUploader: ContentResolver = context.contentResolver
    val myfile = createCustomTempFile(context)

    val inputStream = contentUploader.openInputStream(selectedImage) as InputStream
    val outputStream: OutputStream = FileOutputStream(myfile)
    val buf = ByteArray(1024)
    var len: Int
    while (inputStream.read(buf).also { len = it } > 0) outputStream.write(buf, 0, len)
    outputStream.close()
    inputStream.close()

    return myfile
}

fun reduceFileImage(file: File):File{
    val bitmap = BitmapFactory.decodeFile(file.path)
    var compressImage = 100
    var streamLength: Int

    do{
        val bitmapSream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, compressImage, bitmapSream)
        val imageByteArray = bitmapSream.toByteArray()
        streamLength = imageByteArray.size
        compressImage -= 5
    } while ( streamLength > MAX_SIZE)
    bitmap.compress(Bitmap.CompressFormat.JPEG, compressImage,FileOutputStream(file))
    return file
}