package com.example.storyapp.ViewModel

import android.content.ContentValues.TAG
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.storyapp.ApiConfig.RetrofitBuild
import com.example.storyapp.ApiResponse.AddStoriesResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response


class AddStoryViewModel: ViewModel() {
    private val uploadStory = MutableLiveData<AddStoriesResponse>()

    fun uploadToServer(token: String, image: MultipartBody.Part, description: RequestBody, lat: RequestBody?, lon: RequestBody?){
        val service = RetrofitBuild.getApiService().addNewStory(token,image, description, lat, lon)
        service.enqueue(object : retrofit2.Callback<AddStoriesResponse> {
            override fun onResponse(
                call: Call<AddStoriesResponse>,
                response: Response<AddStoriesResponse>
            ) {
                if(response.isSuccessful){
                    uploadStory.value = response.body()
                }

            }

            override fun onFailure(call: Call<AddStoriesResponse>, t: Throwable) {
                Log.e(TAG,"failure:${t.message}")

            }

        })

    }

    fun uploadStory(): LiveData<AddStoriesResponse>{
        return uploadStory
    }

}