package com.example.storyapp.ViewModel

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.storyapp.ApiResponse.ListStoryItem
import com.example.storyapp.Repository.StoryRepository
import com.example.storyapp.di.Injection
import kotlinx.coroutines.flow.Flow
import java.lang.IllegalArgumentException


class NewMainViewModel(private val repository: StoryRepository): ViewModel() {

    fun getStoryResult(): LiveData<PagingData<ListStoryItem>> = repository.getStory()

    companion object{
        fun takeData(items: List<ListStoryItem>): PagingData<ListStoryItem>{
            return  PagingData.from(items)
        }
    }

}

class ViewModelFactory(private val context: Context): ViewModelProvider.Factory{
    override fun <T: ViewModel> create(modelClass: Class<T>): T{
        if (modelClass.isAssignableFrom(NewMainViewModel::class.java)){
            @Suppress("UNCHECKED")
            return NewMainViewModel(Injection.injectRepository(context)) as T
        }
        throw IllegalArgumentException("Unknown ViewModel")
    }
}

