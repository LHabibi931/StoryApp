package com.example.storyapp.CustomView

import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.text.method.TransformationMethod
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.example.storyapp.R

class PasswordEditText: AppCompatEditText, View.OnTouchListener {

    private lateinit var passwordImage: Drawable
    private var isPasswordVisible = false


    constructor(context: Context): super(context){
        init()

    }

    constructor(context: Context, attrs: AttributeSet): super(context, attrs){
        init()

    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int): super(context, attrs,defStyleAttr){
        init()


    }

    override fun onTouch(view: View, mev: MotionEvent): Boolean {
        TODO("Not yet implemented")
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        val transformationMethod: TransformationMethod = if (isPasswordVisible){
            HideReturnsTransformationMethod.getInstance()}
        else{
            PasswordTransformationMethod.getInstance()
        }
        transformationMethod.let { setTransformationMethod(it) }

    }

    private fun init(){
        passwordImage = ContextCompat.getDrawable(context, R.drawable.baseline_password_24) as Drawable
        setCompoundDrawablesWithIntrinsicBounds(passwordImage,null, null,null)

        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(cs: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val passwordLength = cs?.length ?: 0
                error = if(passwordLength< 8){ context.getString(R.string.pass_hint)}
                        else{null}
            }

            override fun afterTextChanged(p0: Editable?) {

            }

        })
    }

}