package com.example.storyapp.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.google.android.gms.common.util.VisibleForTesting
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

@VisibleForTesting
fun<T> LiveData<T>.getAwaitValue(
    time: Long = 2,
    timeUnit: TimeUnit = TimeUnit.SECONDS,
    afterObserve: ()-> Unit ={}
): T{
    var data: T? = null
    val latch = CountDownLatch(1)
    val observer = object : Observer<T>{
        override fun onChanged(value: T) {
            data = value
            latch.countDown()
            this@getAwaitValue.removeObserver(this)
        }
    }

    this.observeForever(observer)
    try{
        afterObserve.invoke()
        if(!latch.await(time, timeUnit)){
            throw TimeoutException("Live Data Never set")

        }
    }
    finally {
        this.removeObserver(observer)
    }

    @Suppress("NOT_CHECKED")
    return data as T
}

suspend fun <T> LiveData<T>.observeTesting(block: suspend () -> Unit){
    val observer = Observer<T>{}
        try {
            observeForever(observer)
            block
        }
        finally {
            removeObserver(observer)
        }

}

