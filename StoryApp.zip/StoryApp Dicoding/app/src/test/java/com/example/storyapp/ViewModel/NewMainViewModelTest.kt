package com.example.storyapp.ViewModel

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.paging.AsyncPagingDataDiffer
import androidx.paging.PagingData
import androidx.recyclerview.widget.ListUpdateCallback
import com.example.storyapp.Adapter.ListStoryAdapter
import com.example.storyapp.ApiResponse.ListStoryItem
import com.example.storyapp.Dummy.FakeData
import com.example.storyapp.Repository.StoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.`when`
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class NewMainViewModelTest{

    @Mock private lateinit var repository: StoryRepository
    private lateinit var viewModel: NewMainViewModel
    private val fakeData = FakeData.generateFakeDataModel()


    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    @OptIn(ExperimentalCoroutinesApi::class)
    @Before
    fun setUp(){
        viewModel = NewMainViewModel(repository)
        Dispatchers.setMain(TestCoroutineDispatcher())
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    @After
    fun tearDown(){
        Dispatchers.resetMain()
    }

    val updateCallback = object: ListUpdateCallback{
        override fun onInserted(position: Int, count: Int) {}
        override fun onRemoved(position: Int, count: Int) {}
        override fun onMoved(fromPosition: Int, toPosition: Int) {}
        override fun onChanged(position: Int, count: Int, payload: Any?) {}

    }


    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `ketika berhasil memuat cerita`() = runTest{
        val fakePagingData: PagingData<ListStoryItem> = NewMainViewModel.takeData(fakeData)
        val expectedResult = MutableLiveData<PagingData<ListStoryItem>>()
        expectedResult.value = fakePagingData

        `when`(repository.getStory()).thenReturn(expectedResult)

        val actualResult = viewModel.getStoryResult().getAwaitValue()
        Mockito.verify(repository).getStory()

        val diff = AsyncPagingDataDiffer(
            diffCallback = ListStoryAdapter.CALLBACK,
            updateCallback = updateCallback,
            workerDispatcher = Dispatchers.Default
        )
        diff.submitData(actualResult)

        assertNotNull(actualResult)
        assertEquals(fakeData, diff.snapshot())
        assertEquals(fakeData.size , diff.snapshot().size)
        assertEquals(fakeData[0], diff.snapshot()[0])

    }


    @OptIn(ExperimentalCoroutinesApi::class)
    @Test
    fun `ketika tidak ada data cerita`() = runTest{
        val fakePagingEmptyData: PagingData<ListStoryItem> = PagingData.empty()
        val expectedResult = MutableLiveData<PagingData<ListStoryItem>>()
        expectedResult.value = fakePagingEmptyData

        `when`(repository.getStory()).thenReturn(expectedResult)
        val actualResult = viewModel.getStoryResult().getAwaitValue()
        Mockito.verify(repository).getStory()

        val diff = AsyncPagingDataDiffer(
            diffCallback = ListStoryAdapter.CALLBACK,
            updateCallback = updateCallback,
            workerDispatcher = Dispatchers.Default
        )
        diff.submitData(actualResult)

        assertEquals(0, diff.snapshot().size)

    }

}