package com.example.storyapp.Dummy

import com.example.storyapp.ApiResponse.ListStoryItem

object FakeData {
    fun generateFakeDataModel(): List<ListStoryItem>{
        val storyList = arrayListOf<ListStoryItem>()
        for(i in 0..5){
            val story = ListStoryItem(
                "https://story-api.dicoding.dev/images/stories/photos-1641623658595_dummy-pic.png",
            "2022-01-08T06:34:18.598Z",
            "Sigit",
                "ini deskripsi",
                -10.212,
                "id $i",
                -16.002
            )
            storyList.add(story)
        }
        return storyList
    }

}